// Bernardo Morais, MAtricula: 565524
public class TP02Q02Ciframento{   
   // @param txt = texto a ser encriptado
   // @param xx  = variacao
   // @param txtlength = tamanho
   public static String encriptador ( String txt, int xx, int txtlength )
   {
      String txtCifrado = "", txtCifrado2 = "";
      if ( xx <= txtlength-1 )
      {
         // Transforma o caracter em codigo ASCII e faz a criptografia
         int letraCifradaASCII = ((int) txt.charAt(xx)) + 3;
         // Transforma codigo ASCII criptografado em caracter ao novo texto
         txtCifrado2 = txtCifrado2 + (char)letraCifradaASCII + encriptador(txt, xx+1, txtlength);
      }
      return (txtCifrado2);
   }
   
   // metodo para executar a conversao atravez da funcao "encriptador"
   public static void metodo01 ( String abc ){
      String frase = "", convertido = "";
      if ( abc != null )
      {
         frase = abc;
         convertido = encriptador( frase, 0, frase.length());       
         MyIO.println (convertido);
      }
   }
   
   public static void main (String[] args){
      String[] entrada = new String[1000];
      String linha;
      int numEntrada = 0;
   
      //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
      } while (entrada[numEntrada++].equals("FIM") == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
   
      //Para cada linha de entrada, gerando uma de saida contendo o numero de letras maiusculas da entrada
      for(int i = 0; i < numEntrada; i++){
         metodo01(entrada[i]);
      }
   }
}