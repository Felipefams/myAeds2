// Programa feito por Bernardo Morais, Matricula: 565524
public class TP02Q05Is{   
   // esta funcao int analisa se a string e composta somente por vogais retornando true
   // @param frase = string a ser convertida
   // @param y = int inicial e variacao
   public static boolean vogais ( String frase, int y ){
      boolean resposta = true;
      if ( y <= frase.length()-1 ){
         if ( frase.charAt(y) == 'a' || frase.charAt(y) == 'e' || frase.charAt(y) == 'i' || frase.charAt(y) == 'o' || frase.charAt(y) == 'u' || frase.charAt(y) == 'A' || frase.charAt(y) == 'E' || frase.charAt(y) == 'I' || frase.charAt(y) == 'O' || frase.charAt(y) == 'U' ) {
            resposta = resposta && true && vogais(frase,y+1);
         }
         else{
            resposta = resposta && false && vogais(frase,y+1);
         }
      }
      return (resposta);
   }
   
   // esta funcao int analisa se a string e composta somente por consoantes retornando true
   public static boolean consoantes ( String frase, int y )
   {
      boolean resposta = true;
      if ( y <= frase.length()-1 )
      {
         if ( !(frase.charAt(y) == 'a' || frase.charAt(y) == 'e' || frase.charAt(y) == 'i' || frase.charAt(y) == 'o' || frase.charAt(y) == 'u' || frase.charAt(y) == 'A' || frase.charAt(y) == 'E' || frase.charAt(y) == 'I' || frase.charAt(y) == 'O' || frase.charAt(y) == 'U') && 'a' <= frase.charAt(y) && frase.charAt(y) <= 'z' || 'A' <= frase.charAt(y) && frase.charAt(y) <= 'Z' ){
            resposta = resposta && true && consoantes( frase, y+1 );
         }
         else{
            resposta = resposta && false && consoantes( frase, y+1 );
         }
      }
      return (resposta);
   }
   
   // testar se e numeros
   public static boolean numeros ( String frase, int y )
   {
      boolean resposta = true;
      if ( y <= frase.length()-1 ){
         if ( frase.charAt(y) == '0' || frase.charAt(y) == '1' || frase.charAt(y) == '2' || frase.charAt(y) == '3' || frase.charAt(y) == '4' || frase.charAt(y) == '5' || frase.charAt(y) == '6' || frase.charAt(y) == '7' || frase.charAt(y) == '8' || frase.charAt(y) == '9' ){
            resposta = resposta && true && numeros(frase,y+1);
         }
         else{
            resposta = resposta && false && numeros(frase,y+1);
         }
      }
      return (resposta);
   }
   
   public static boolean reais ( String frase, int y, int z ){
      boolean resposta = true;
      if ( y <= frase.length()-1 ){
         if ( frase.charAt(y) == '.'|| frase.charAt(y) == ',' ){
            z = z + 1;
         }
         if ( frase.charAt(y) == '0' || frase.charAt(y) == '1' || frase.charAt(y) == '2' || frase.charAt(y) == '3' || frase.charAt(y) == '4' || frase.charAt(y) == '5' || frase.charAt(y) == '6' || frase.charAt(y) == '7' || frase.charAt(y) == '8' || frase.charAt(y) == '9' || frase.charAt(y) == '.' || frase.charAt(y) == ',' && z <= 1){
            resposta = resposta && true && reais(frase, y+1, z);
         }
         else{
            resposta = resposta && false && reais(frase, y+1, z);
         }
      }
      if ( z > 1 ){
         resposta = resposta && false;
      }
      return (resposta);
   }
   
   public static void metodo01 ( String abc ){
      String resposta = "";
      boolean resp1, resp2, resp3, resp4;
      if ( abc != null ){
         resp1 = vogais(abc,0);
         if (resp1){
         resposta = resposta + "SIM ";
         }
         else{
         resposta = resposta + "NAO ";
         }
         resp2 = consoantes(abc,0);
         if (resp2){
         resposta = resposta + "SIM ";
         }
         else{
         resposta = resposta + "NAO ";
         }
         resp3 = numeros(abc, 0);
         if (resp3){
         resposta = resposta + "SIM ";
         }
         else{
         resposta = resposta + "NAO ";
         }
         resp4 = reais(abc, 0, 0);
         if (resp4){
         resposta = resposta + "SIM ";
         }
         else{
         resposta = resposta + "NAO ";
         }
         MyIO.println(""+resposta);
      }
   }
   
   public static void main (String[] args){
      String[] entrada = new String[1000];
      String linha;
      int numEntrada = 0;
      //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
      } while (entrada[numEntrada++].equals("FIM") == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
      //Para cada linha de entrada, gerando uma de saida contendo o numero de letras maiusculas da entrada
      for(int i = 0; i < numEntrada; i++){
         metodo01(entrada[i]);
      }
   }
   
/*
 * teste efetuado com linha 523 pub.in
 * resposta obtida: 1 228 121 100
*/
}