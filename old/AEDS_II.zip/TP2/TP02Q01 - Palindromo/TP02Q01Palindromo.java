// Bernardo Morais, Matricula: 565524
public class TP02Q01Palindromo
{
   // boolean recursiva que testa o parametro enviado pelo metodo principal
   // @param pali = string de entrada
   // @param ab = 0
   // @param bc = tamanho da string pali
   public static boolean verificarpalindromo ( String pali, int ab, int bc ){
      boolean resposta = true;
      String inverso = "";
      if ( pali != null ){
         inverso = pali;
         if ( ab < bc ){
            if ( inverso.charAt(ab) != inverso.charAt(bc) ){
               resposta = false;
            }
            else{
               resposta = verificarpalindromo(inverso, ab+1, bc-1);
            }
         }
      }
      else{
         MyIO.println ("ERRO, Null.");
         resposta = false;
      }
      return (resposta);
   }
   
   // metodo para dizer se e ou nao palindromo
   public static void metodo01 ( String abc ){
      String frase = "";
      int length = 0;
      if ( abc != null ){
         frase = abc;
         length = frase.length()-1;
         boolean teste = verificarpalindromo(frase, 0, length);
         if ( teste ){
            MyIO.println ("SIM");
         }
         else{
            MyIO.println ("NAO");
         }
      }
   }
   
   public static void main (String[] args){
      String[] entrada = new String[1000];
      String linha;
      int numEntrada = 0;
   
      //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
      } while (entrada[numEntrada++].equals("FIM") == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
   
      //Para cada linha de entrada, gerando uma de saida contendo o numero de letras maiusculas da entrada
      for(int i = 0; i < numEntrada; i++){
         metodo01(entrada[i]);
      }
   }
}