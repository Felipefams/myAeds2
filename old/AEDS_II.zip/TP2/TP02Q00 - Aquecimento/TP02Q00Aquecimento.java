// Programa feito por bernardo morais, matricula: 565524
class TP02Q00Aquecimento {
   public static boolean isMaiuscula (char c){
      return (c >= 'A' && c <= 'Z');
   }
   
   public static void contarLetrasMaiusculas(String s){
      contarLetrasMaiusculas(s, 0, 0);
   }
   public static void contarLetrasMaiusculas(String s, int i, int contador){
      if(i < s.length()){
         if (s.charAt(i) >= 'A' && s.charAt(i) <= 'Z'){
            contarLetrasMaiusculas(s, i + 1, contador + 1);
         } 
         else {
            contarLetrasMaiusculas(s, i + 1, contador);
         }
      }
      if(i >= s.length() ){
         MyIO.println(contador);
      }
   }

   public static void main (String[] args){
      String[] entrada = new String[1000];
      String linha;
      int numEntrada = 0;
   
      //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
      } while (entrada[numEntrada++].equals("FIM") == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
   
      //Para cada linha de entrada, gerando uma de saida contendo o numero de letras maiusculas da entrada
      for(int i = 0; i < numEntrada; i++){
         contarLetrasMaiusculas(entrada[i]);
      }
   }
}
