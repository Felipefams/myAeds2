// Programa feito por Bernardo Morais, Matricula: 565524
class TP01Q02Ciframento {
   // metodo para converter o texto inserido em uma cifra
   public static void encriptador ( String abc )
   {
      String txtCifrado = "", txtCifrado2 = "";
      String txt = "", convertido = "";
      if ( abc != null ){
         txt = abc;      
         int txtlength = txt.length();
      
         for(int c=0; c < txtlength; c++){
         // Transforma o caracter em codigo ASCII e faz a criptografia modificando o numero do caractere
            int letraCifradaASCII = ((int) txt.charAt(c)) + 3;
         
         // Transforma codigo ASCII criptografado em caracter ao novo texto
            txtCifrado2 = txtCifrado2 + (char)letraCifradaASCII;
         }
      }
      convertido = txtCifrado2;
      MyIO.println (convertido);
   }
   
   public static void main (String[] args){
      String[] entrada = new String[1000];
      String linha;
      int numEntrada = 0;
   
      //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
      } while (entrada[numEntrada++].equals("FIM") == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
   
      //Para cada linha de entrada, gerando uma de saida contendo o numero de letras maiusculas da entrada
      for(int i = 0; i < numEntrada; i++){
         encriptador(entrada[i]);
      }
   }
   
}