#include<stdio.h>
#include<stdlib.h>
#include<string.h>
// Programa feito por Bernardo Morais, Matricula: 565524
int verifica_palindrome(char *palavra){
   int tamanho = strlen(palavra);
   int resposta = 1;
   for(int i = 0, j = tamanho-1; i<tamanho/2; i++,j-- )
   {
      if(palavra[i] != palavra[j]){
         resposta = 0;
         i=tamanho;
      }
   }
   return resposta;
}

int main (int argc, char **argv){
   char *linha = (char*) malloc(1000*sizeof(char));
   
   while(strcmp(linha,"FIM") != 0){
      scanf(" %[^\n]s", linha);
      if ( strcmp(linha,"FIM") != 0 )
      {
      if ( verifica_palindrome(linha) == 1 ) {
         printf ("SIM");
      }
      else{
         printf ("NAO");
      }
      printf("\n");
      }
      setbuf(stdin, NULL);
   }
}

