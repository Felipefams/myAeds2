// Programa feito por Bernardo Morais, Matricula: 565524
class TP01Q04Booleana{   
   
   // metodo que retorna qual a sequencia dos 3 primeiros binarios
   public static int getbins ( String bins ){
      int resposta = 0;
      if ( bins.charAt(0) == 48 && bins.charAt(2) == 48 && bins.charAt(4) == 48 ){
         resposta = 0;
      } 
      else if ( bins.charAt(0) == 48 && bins.charAt(2) == 48 && bins.charAt(4) == 49 ){
         resposta = 1;
      }
      else if ( bins.charAt(0) == 48 && bins.charAt(2) == 49 && bins.charAt(4) == 48 ){
         resposta = 2;
      }
      else if ( bins.charAt(0) == 48 && bins.charAt(2) == 49 && bins.charAt(4) == 49 ){
         resposta = 3;
      }
      else if ( bins.charAt(0) == 49 && bins.charAt(2) == 48 && bins.charAt(4) == 48 ){
         resposta = 4;
      }
      else if ( bins.charAt(0) == 49 && bins.charAt(2) == 48 && bins.charAt(4) == 49 ){
         resposta = 5;
      }
      else if ( bins.charAt(0) == 49 && bins.charAt(2) == 49 && bins.charAt(4) == 48 ){
         resposta = 6;
      }
      else if ( bins.charAt(0) == 49 && bins.charAt(2) == 49 && bins.charAt(4) == 49 ){
         resposta = 7;
      }
      return resposta;
   }
   
   //metodo para retornar 1 ou 0 em OR de duas letras
   public static int gettwoor ( char a, char b ){
      int resposta = 0;
      if ( a == 49 || b == 49 ){
         resposta = 1;
      }
      return resposta;
   }
   
   //metodo para retornar 1 ou 0 em AND de duas letras
   public static int gettwoand ( char a, char b ){
      int resposta = 0;
      if ( a == 49 && b == 49 ){
         resposta = 1;
      }
      return resposta;
   }

   public static void metodo01 ( String abc ){
      String frase = "", entradas = "", tipo = "";
      int bina, binb;
      boolean resposta = false, x = false, y = false;
      if ( abc.charAt(0) == '2'  && abc != null ){  
         // compara se os binarios de entrada sao falso ou verdadeiros
         // bina = primeiro binario
         // x = verdadeiro se 1 ou falso se 0
         if ( abc.charAt(2) == 49 ){
            bina = 1;
            x = true;
         }
         else if ( abc.charAt(2) == 48 ){
            bina = 0;
            x = false;
         }
         // binb = segundo binario
         // y = verdadeiro se 1 ou falso se 0
         if ( abc.charAt(4) == 49 ){
            binb = 1;
            y = true;
         }
         else if ( abc.charAt(4) == 48 ){
            binb = 0;
            y = false;
         }
         // descobre se e and ou not para 2 binarios
         tipo = tipo + abc.charAt(6) + abc.charAt(7) + abc.charAt(8);
         // entra no if se for and e no else se for not
         if ( tipo.charAt(0) == 'a' ){
            // transforma os binarios se for not
            if ( abc.charAt(10) == 'n' ){
               if ( x ){
                  bina = 0;
                  x = false;
               }
               else{
                  bina = 1;
                  x = true;
               }
            }
            // transforma o segundo binario se for not
            if ( abc.charAt(19) == 'n' ){
               if ( y ){
                  binb = 0;
                  y = false;
               }
               else{
                  binb = 1;
                  y = true;
               }
            }
            resposta = x && y;
            // imprimi a resposta true or false
            if ( resposta ){
               MyIO.println ("1");
            }
            else{
               MyIO.println ("0");
            }
         }
         // para not(and:
         else if ( tipo.charAt(0) == 'n' ){
            if ( x && y ){
               y = false;
               x = false;
            } 
            else{
               x = true;
               y = true;
            }
            resposta = x && y;
            if ( resposta ){
               MyIO.println ("1");
            }
            else{
               MyIO.println ("0");
            }
         }
      }
      // para strings com 3 binarios/booleanos
      else if ( abc.charAt(0) == '3' ){
         String pegarbins = "" + abc.charAt(2) + abc.charAt(3) + abc.charAt(4) + abc.charAt(5) + abc.charAt(6);
         int bins = getbins(pegarbins);
         if ( abc.charAt(8) == 'a' && abc.length() <= 42 ){
            if ( abc.charAt(12) == 'o' ){
               if ( bins == 0 ){// 0 0 0
                  MyIO.println("0");
               }
               else if ( bins == 1 ){// 0 0 1
                  MyIO.println("0");
               }
               else if ( bins == 2 ){// 0 1 0
                  if ( abc.charAt(15) == 'A' && abc.charAt(19) == 'B' ){
                     MyIO.println("1");
                  }
                  else{
                     MyIO.println("0");
                  }
               }
               else if ( bins == 3 ){// 0 1 1
               
               }
               else if ( bins == 4 ){// 1 0 0
               
               }
               else if ( bins == 5 ){// 1 0 1
               
               }
               else if ( bins == 6 ){// 1 1 0
               
               }
               else if ( bins == 7 ){// 1 1 1
               
               }
            }
         }     
         else if ( abc.charAt(8) == 'o' ){
            //
         }     
      }      
   }
   
   public static void main (String[] args){
      String[] entrada = new String[1000];
      String linha;
      int numEntrada = 0;
      //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
      } while (entrada[numEntrada++].equals("0") == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
      //Para cada linha de entrada, gerando uma de saida contendo o numero de letras maiusculas da entrada
      for(int i = 0; i < numEntrada; i++){
         metodo01(entrada[i]);
      }
   }
   
/*
 * teste efetuado com que
 * resposta obtida: fue
*/
}