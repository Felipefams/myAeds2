// Programa feito por Bernardo Morais, Matricula: 565524
import java.util.Random;
class TP01Q03Aleatoria{   
   // metodo que recebe a string e os caracteres como parametro
   // efetuando a troca atravez de uma iteracao
   public static String trocar ( String frase, char x, char y )   {
      String trocar = "";
      int z;
      for ( z = 0; z < frase.length(); z++ ){
         if ( frase.charAt(z) == x ){
            trocar = trocar + y;
         }
         else{
            trocar = trocar + frase.charAt(z);
         }
      }
      return trocar;
   }
   public static void metodo01 ( Random gerador, String abc ){
      String frase = "", convertido = "";
      // caractere que sera substituido pela letra aleatoria
      char x = (char)('a' + (Math.abs(gerador.nextInt()) % 26));
      // caractere que entrara no lugar do caractere a cima
      char y = (char)('a' + (Math.abs(gerador.nextInt()) % 26));
      
      if ( abc != null ){
         frase = abc;
         convertido = trocar(frase, x, y);       
         MyIO.println (convertido);
      }
   }
   
   public static void main (String[] args){
      String[] entrada = new String[1000];
      String linha;
      int numEntrada = 0;
      Random gerador = new Random();
      gerador.setSeed(4);
      //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
      } while (entrada[numEntrada++].equals("FIM") == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
      //Para cada linha de entrada, gerando uma de saida contendo o numero de letras maiusculas da entrada
      for(int i = 0; i < numEntrada; i++){
         metodo01(gerador, entrada[i]);
      }
   }
}