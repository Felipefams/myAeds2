// Programa feito por Bernardo Morais, Matricula: 565524
class TP01Q01Palindromo {
   
   // Metodo para comparar caracteres
   public static boolean isEquals (char x, char y){
      return (x == y);
   }
   
   // metodo que retorna true se for palindromo e false se nao for,
   // o metodo compara a primeira letra com a ultima ate chegar no meio.
   public static boolean palindromo (String s){
      boolean resp = true;
      int tamanho = s.length();
      int fim = tamanho - 1;
      for(int inicio = 0; inicio < tamanho; inicio++){
         resp = resp && isEquals( s.charAt(inicio),s.charAt(fim) );       
         fim = fim - 1;   
      }
      return resp;
   }
 
   public static void main (String[] args){
      MyIO.setCharset("UTF-8");
      String[] entrada = new String[1000];
      String linha;
      int numEntrada = 0;
 
      //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
      } while (entrada[numEntrada++].equals("FIM") == false);
      
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
      boolean resp;
      for(int i = 0; i < numEntrada; i++){
         resp = palindromo(entrada[i]);
         if ( resp ){
            MyIO.println("SIM");
         }
         else {
            MyIO.println("NAO");
         }
      }
   }
}