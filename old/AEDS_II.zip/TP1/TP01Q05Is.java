// Programa feito por Bernardo Morais, Matricula: 565524
class TP01Q05Is{   

   // esta funcao int analisa se a string e composta somente por vogais retornando true
   public static boolean vogais ( String frase ){
      boolean resposta = true;
      int y;
      for ( y = 0; y < frase.length(); y = y + 1 ){
         if ( frase.charAt(y) == 'a' || frase.charAt(y) == 'e' || 
              frase.charAt(y) == 'i' || frase.charAt(y) == 'o' || 
              frase.charAt(y) == 'u' || frase.charAt(y) == 'A' || 
              frase.charAt(y) == 'E' || frase.charAt(y) == 'I' || 
              frase.charAt(y) == 'O' || frase.charAt(y) == 'U' ){
            resposta = resposta && true;
         }
         else{
            resposta = resposta && false;
         }
      }
      return (resposta);
   }
   
   // esta funcao int analisa se a string e composta somente por consoantes retornando true
   public static boolean consoantes ( String frase ){
      boolean resposta = true;
      int y;
      for ( y = 0; y < frase.length(); y = y + 1 ){
         if ( !(frase.charAt(y) == 'a' || frase.charAt(y) == 'e' ||
                frase.charAt(y) == 'i' || frase.charAt(y) == 'o' || 
                frase.charAt(y) == 'u' || frase.charAt(y) == 'A' || 
                frase.charAt(y) == 'E' || frase.charAt(y) == 'I' ||
                frase.charAt(y) == 'O' || frase.charAt(y) == 'U') && 
                'a' <= frase.charAt(y) && frase.charAt(y) <= 'z' || 
                'A' <= frase.charAt(y) && frase.charAt(y) <= 'Z' ){
            resposta = resposta && true;
         }
         else{
            resposta = resposta && false;
         }
      }
      return (resposta);
   }
   
   public static boolean numeros ( String frase ){
      boolean resposta = true;
      int y;
      for ( y = 0; y < frase.length(); y = y + 1 ){
         if ( frase.charAt(y) == '0' || frase.charAt(y) == '1' ||
              frase.charAt(y) == '2' || frase.charAt(y) == '3' || 
              frase.charAt(y) == '4' || frase.charAt(y) == '5' ||
              frase.charAt(y) == '6' || frase.charAt(y) == '7' ||
              frase.charAt(y) == '8' || frase.charAt(y) == '9' ){
            resposta = resposta && true;
         }
         else{
            resposta = resposta && false;
         }
      }
      return (resposta);
   }
   
   public static boolean reais ( String frase ){
      boolean resposta = true;
      int y, z = 0;
      for ( y = 0; y < frase.length(); y = y + 1 ){
         if ( frase.charAt(y) == '.'|| frase.charAt(y) == ',' ){
            z = z + 1;
         }
         
         if ( frase.charAt(y) == '0' || frase.charAt(y) == '1' ||
              frase.charAt(y) == '2' || frase.charAt(y) == '3' || 
              frase.charAt(y) == '4' || frase.charAt(y) == '5' ||
              frase.charAt(y) == '6' || frase.charAt(y) == '7' ||
              frase.charAt(y) == '8' || frase.charAt(y) == '9' ||
              frase.charAt(y) == '.' || frase.charAt(y) == ',' ){
            resposta = resposta && true;
         }
         else{
            resposta = resposta && false;
         }
      }
      if ( z > 1 ){
         resposta = resposta && false;
      }
      return (resposta);
   }
   
   public static void metodo01 ( String abc ){
      String resposta = "";
      boolean resp1, resp2, resp3, resp4;
      
      if ( abc != null ){
         resp1 = vogais(abc);
         if (resp1){
            resposta = resposta + "SIM ";
         }
         else{
            resposta = resposta + "NAO ";
         }
         resp2 = consoantes(abc);
         if (resp2){
            resposta = resposta + "SIM ";
         }
         else{
            resposta = resposta + "NAO ";
         }
         resp3 = numeros(abc);
         if (resp3){
            resposta = resposta + "SIM ";
         }
         else{
            resposta = resposta + "NAO ";
         }
         resp4 = reais(abc);
         if (resp4){
            resposta = resposta + "SIM ";
         }
         else{
            resposta = resposta + "NAO ";
         }
         MyIO.println(""+resposta);
      }
   }
   
   public static void main (String[] args){
      String[] entrada = new String[1000];
      String linha;
      int numEntrada = 0;
      //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
      } while (entrada[numEntrada++].equals("FIM") == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
      //Para cada linha de entrada, gerando uma de saida contendo o numero de letras maiusculas da entrada
      for(int i = 0; i < numEntrada; i++){
         metodo01(entrada[i]);
      }
   }
}